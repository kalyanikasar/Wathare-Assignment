const express = require("express");
const cors=require("cors");
const dbConnect = require("./db");
const app = express();
//app.use(cors("*"));
app.use(cors({
    origin: '*'
}));
// app.use((req, res, next) => {
//     res.setHeader('Access-Control-Allow-Origin', '*');
//     res.setHeader('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authortization');
//     res.setHeader('Acces-Control-Allow-Methods', 'GET, POST, PATCH, DELETE');
// });

app.get("/", async (req, resp) => {
    let data = await dbConnect();
    data = await data.find().toArray();
    console.log(data)
  resp.send(data);
});

app.listen(3000);
