const { MongoClient } = require('mongodb');
const cors = require('cors');
const url = 'mongodb://127.0.0.1:27017/user';
const databaseName = 'user'
const client = new MongoClient(url);

async function dbConnect()
{
  let result = await client.connect();
  db = result.db(databaseName);
  return db.collection('Language');
}
module.exports = dbConnect;