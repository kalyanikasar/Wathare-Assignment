import { useEffect, useState } from 'react';
import './App.css';
import {Chart, Tooltip, Title, ArcElement, Legend} from 'chart.js';
import { Pie } from 'react-chartjs-2';
Chart.register(
  Tooltip, Title, ArcElement, Legend
);

const data = {
  datasets: [{
      data: [33, 33, 34],
      backgroundColor:[
        'red',
        'blue',
        'yellow'
      ]
  },
],

  labels: [
      'Red',
      'Yellow',
      'Blue'
  ]
};


function App() {
  const [data, setData] = useState({
    datasets: [{
        data: [33, 33, 34],
        backgroundColor:[
          'red',
          'blue',
          'yellow'
        ]
    },
  ],
  
    labels: [
        'PHP',
        'Java',
        'JavaScript'
    ],
  });
  useEffect(()=> {
    const fetchData = () => {
      fetch('http://localhost:3000').catch(d=>{console.log(d);}).then(data => {
        const res = data.json();
        console.log("response"+res);
        return res
        
      }).then((res) => {
        console.log("ress", res)
        const label = [];
        const data = [];
        for(var i of res) {
          label.push(i.name);
          data.push(i.id);
        }
        setData({
          datasets: [{
              data: data,
              backgroundColor:[
                'red',
                'blue',
                'yellow'
              ]
          },
        ],
         labels:label,
        })
      }).catch(e => {
        console.log("error", e)
      })
    }
  fetchData();
  }, [])
  return (
    <div className="App" style={{
      width: '30%',
      height: '30%',
  }}>
      <Pie data={data}/>
    </div>
  );
}

export default App;
